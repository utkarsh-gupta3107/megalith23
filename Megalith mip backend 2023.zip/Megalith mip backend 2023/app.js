require('dotenv').config();
const mongoose = require('mongoose');
const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const nodemailer = require('nodemailer');
const { google } = require('googleapis');
const session = require('express-session');
const passport = require('passport');
const passportLocalMongoose = require('passport-local-mongoose');
const app = express();
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());//used
app.use(cors());//middlewares
app.use(session({
    secret: "Rusty is a dog",
    resave: false,
    saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

//DB CONNECTION

mongoose.connect("mongodb://localhost:27017/megalith_mip", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("DB CONNECTED");
}).catch((err) => {
    console.log(err);
});
//=================API KEYS========================
// These id's and secrets should come from .env file.
const CLIENT_ID = '504976362886-ld0uqsmbdh57bh1pmvvl8m5osfcsqk77.apps.googleusercontent.com';
const CLEINT_SECRET = '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';
const REDIRECT_URI = 'https://developers.google.com/oauthplayground';
const REFRESH_TOKEN = '1//040e3AXMK6cj6CgYIARAAGAQSNwF-L9Ir0WU85SnhpYH5eBNfqMy-mb03hRA2PLzwtFinMkCyUCAf88TvNlP1Yitb0bA81J4Hn9c';
const jwtSecret = 'some super secret';
//=================================================
//User Schema
//=================================================
const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        trim: true
    },
    databaseEmail: {
        type: String,
        required: true
    },
    password: {
        type: String,
    },
    mobileNumber: {
        type: Number,
        required: true,
        trim: true
    },
    college: {
        type: String,
        required: true,
        trim: true
    },
    country: {
        type: String,
        required: true,
        trim: true
    },
    state: {
        type: String,
        required: true,
        trim: true
    },
    city: {
        type: String,
        required: true,
        trim: true
    },
    gender: {
        type: String,
        required: true,
        trim: true
    },
    yearsOfStudy: {
        type: Number,
        trim: true
    },
    partOrNot: {
        type: String,
        required: true,
        trim: true
    }
});

userSchema.plugin(passportLocalMongoose);
const User = mongoose.model("User", userSchema);
//=======================================================     
passport.use(User.createStrategy());
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());
//========================================================

//=====================
// ROUTES
//=====================

// Showing home page
app.get("/", function (req, res) {
    res.render("home");
});

// Showing secret page
app.get("/secret", isLoggedIn, function (req, res) {
    res.render("secret");
});

// Showing signup form
app.get("/signup", function (req, res) {
    res.render("signup");
});

// Handling user signup
app.post("/signup", function (req, res) {

    User.register({
        username: req.body.username,
        databaseEmail: req.body.email,
        mobileNumber: req.body.mobileNumber,
        college: req.body.college,
        country: req.body.countrylist,
        state: req.body.statelist,
        city: req.body.citylist,
        gender: req.body.gender,
        yearsOfStudy: req.body.yearsOfStudy,
        partOrNot: req.body.partOrNot
    },
        req.body.password,
        function (err, user) {
            if (err) {
                console.log(err);
                return res.render("signup");
            }
            passport.authenticate("local")(
                req, res, function () {
                    res.render("secret");
                });
        });
});

//Showing login form
app.get("/login", function (req, res) {
    res.render("login");
});

//Handling user login
app.post("/login", passport.authenticate("local", {
    successRedirect: "/secret",
    failureRedirect: "/login",
}), function (req, res) {
});

//Handling user logout
app.get("/logout", function (req, res) {
    res.redirect("/");
});
//Checking For authetication 
function isLoggedIn(req, res, next) {
    if (req.isAuthenticated()) return next();
    res.redirect("/login");
}

app.get('/forgot-password', (req, res, next) => {
    res.render('forgot-password');
});
app.post('/forgot-password', (req, res, next) => {
    const { enteredEmail } = req.body;

    //Make sure user exists inside the database
    User.findOne({ databaseEmail: enteredEmail }, function (err, foundUsers) {
        if (foundUsers) {
            // User exists and now create a one time link valid for 15 minutes
            console.log(foundUsers);
            const databaseEmail = foundUsers.databaseEmail;
            const ID = foundUsers._id.toString();
            const secret = jwtSecret + foundUsers.password;
            const payload = {
                email: databaseEmail,
                id: ID
            }
            const token = jwt.sign(payload, secret, { expiresIn: '15m' })
            const link = `http://localhost:3000/reset-password/${ID}/${token}`
            console.log(link);
            const oAuth2Client = new google.auth.OAuth2(
                CLIENT_ID,
                CLEINT_SECRET,
                REDIRECT_URI
            );
            oAuth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });

            async function sendMail() {
                try {
                    const accessToken = await oAuth2Client.getAccessToken();

                    const transport = nodemailer.createTransport({
                        service: 'gmail',
                        auth: {
                            type: 'OAuth2',
                            user: 'mailme.a.nigam@gmail.com',
                            clientId: CLIENT_ID,
                            clientSecret: CLEINT_SECRET,
                            refreshToken: REFRESH_TOKEN,
                            accessToken: accessToken,
                        },
                    });

                    const mailOptions = {
                        from: 'Abhijeet Nigam <mailme.a.nigam@gmail.com>',
                        to: databaseEmail,
                        subject: 'Hello! Click on the Link',
                        text: 'Hello from gmail email using API and the reset link is ',
                        html: link
                    };

                    const result = await transport.sendMail(mailOptions);
                    return result;
                } catch (error) {
                    return error;
                }
            }

            sendMail()
                .then((result) => console.log('Email sent...', result))
                .catch((error) => console.log(error.message));
            res.send("Password reset Link has been sent to your email...")
        } else {
            console.log(err);
            res.send("Not Found!!");
        }
    });
});
app.get('/reset-password/:ID/:token', (req, res, next) => {
    const { ID, token } = req.params;
    //check if this id exists in database
    //objectId=require('mongodb').ObjectID(ID);
    var objectId = mongoose.Types.ObjectId(ID);
    User.findOne({ _id: objectId }, function (err, foundUsers) {
        if (foundUsers) {
            //We have a valid ID and we have a valid User with this ID
            const secret = jwtSecret + foundUsers.password;
            try {
                const payload = jwt.verify(token, secret);
                res.render('reset-password', { email: foundUsers.databaseEmail })
            } catch (error) {
                console.log(error.message);
                res.send(error.message);
            }
        } else {
            res.send("Invalid User ID");
            return;
        }

    })
});
app.post('/reset-password/:ID/:token', (req, res, next) => {
    const { ID, token } = req.params;
    const { password, password2 } = req.body;
    var objectId = mongoose.Types.ObjectId(ID);
    User.findOne({ _id: objectId }, function (err, foundUsers) {
        if (foundUsers) {
            const secret = jwtSecret + foundUsers.password;
            try {
                const payload = jwt.verify(token, secret);
                //validate password and password2 should match 
                if (password !== password2) {
                    res.send(alert("The passwords are not same! Please see to it!"));
                }
                //we can simply find the user using the payload email and id and update with new password
                /*
                USING BCRYPT AS AN ALTERATIVE BUT USE PASSPORT.JS FIRST FOR HASHING 
                const securePassword= async (password)=>{
                    const passwordHash = await bcrypt.hash(password,5);
                    foundUsers.password = passwordHash;
                }
                //always hash the password before saving
                */
                
                foundUsers.setPassword(password, function(err,user){
                    if (err) {
                        console.log(err)
                        res.json({success: false, message: 'Password could not be saved. Please try again!'});
                    } else { foundUsers.save();
                        console.log(foundUsers);
                        res.redirect("/login"); }
                     });
                
            } catch (error) {
                console.log(error.message);
                res.send(error.message);
            }
        } else {
            res.send("Invalid USER ID");
            return;
        }
    });
    console.log("done till here!!");
});
//===========SENDING PASSWORD RESET LINK THROUGH MAIL======================//
            /*const oAuth2Client = new google.auth.OAuth2(
                CLIENT_ID,
                CLEINT_SECRET,
                REDIRECT_URI
              );
              oAuth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });

              async function sendMail() {
                try {
                  const accessToken = await oAuth2Client.getAccessToken();

                  const transport = nodemailer.createTransport({
                    service: 'gmail',
                    auth: {
                      type: 'OAuth2',
                      user: 'mailme.a.nigam@gmail.com',
                      clientId: CLIENT_ID,
                      clientSecret: CLEINT_SECRET,
                      refreshToken: REFRESH_TOKEN,
                      accessToken: accessToken,
                    },
                  });

                  const mailOptions = {
                    from: 'Abhijeet Nigam <mailme.a.nigam@gmail.com>',
                    to: 'basant.abhijeet2003@gmail.com',
                    subject: 'Hello from gmail using API',
                    text: 'Hello from gmail email using API and the reset link is ',
                    html: '<a href="http://localhost:3000/reset-password/"+User._id+"/"+token>Link</a>',
                  };

                  const result = await transport.sendMail(mailOptions);
                  return result;
                } catch (error) {
                  return error;
                }
              }

              sendMail()
                .then((result) => console.log('Email sent...', result))
                .catch((error) => console.log(error.message));*/

//==============================================================================//

//PORT OR HOSTING
var port = process.env.PORT || 3000;
app.listen(port, function () {
    console.log("Server Has Started!");
});